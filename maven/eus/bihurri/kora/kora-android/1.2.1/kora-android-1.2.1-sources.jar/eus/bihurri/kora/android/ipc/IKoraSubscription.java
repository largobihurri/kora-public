/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /home/pi/Android/Sdk/build-tools/36.0.0/aidl -p/home/pi/Android/Sdk/platforms/android-37.0/framework.aidl -o/tmp/claude-1000/-home-pi-Proyectos-Claude-Sonora/afe0f729-e545-48f0-8b42-d6c759457818/scratchpad/kora-snap/kora-android/build/generated/aidl_source_output_dir/release/out -I/tmp/claude-1000/-home-pi-Proyectos-Claude-Sonora/afe0f729-e545-48f0-8b42-d6c759457818/scratchpad/kora-snap/kora-android/src/main/aidl -I/tmp/claude-1000/-home-pi-Proyectos-Claude-Sonora/afe0f729-e545-48f0-8b42-d6c759457818/scratchpad/kora-snap/kora-android/src/release/aidl -d/tmp/aidl16709061014951660987.d /tmp/claude-1000/-home-pi-Proyectos-Claude-Sonora/afe0f729-e545-48f0-8b42-d6c759457818/scratchpad/kora-snap/kora-android/src/main/aidl/eus/bihurri/kora/android/ipc/IKoraSubscription.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package eus.bihurri.kora.android.ipc;
/** Handle of a subscription opened with IKoraNode.subscribe. */
public interface IKoraSubscription extends android.os.IInterface
{
  /** Default implementation for IKoraSubscription. */
  public static class Default implements eus.bihurri.kora.android.ipc.IKoraSubscription
  {
    /** Stops the subscription. Idempotent; asynchronous so that cleanup never blocks the caller. */
    @Override public void cancel() throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements eus.bihurri.kora.android.ipc.IKoraSubscription
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an eus.bihurri.kora.android.ipc.IKoraSubscription interface,
     * generating a proxy if needed.
     */
    public static eus.bihurri.kora.android.ipc.IKoraSubscription asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof eus.bihurri.kora.android.ipc.IKoraSubscription))) {
        return ((eus.bihurri.kora.android.ipc.IKoraSubscription)iin);
      }
      return new eus.bihurri.kora.android.ipc.IKoraSubscription.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_cancel:
        {
          this.cancel();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements eus.bihurri.kora.android.ipc.IKoraSubscription
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /** Stops the subscription. Idempotent; asynchronous so that cleanup never blocks the caller. */
      @Override public void cancel() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_cancel, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_cancel = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "eus.bihurri.kora.android.ipc.IKoraSubscription";
  /** Stops the subscription. Idempotent; asynchronous so that cleanup never blocks the caller. */
  public void cancel() throws android.os.RemoteException;
}
