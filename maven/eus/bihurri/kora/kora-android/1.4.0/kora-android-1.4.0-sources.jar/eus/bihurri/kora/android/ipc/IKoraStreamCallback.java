/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /home/pi/Android/Sdk/build-tools/36.0.0/aidl -p/home/pi/Android/Sdk/platforms/android-37.0/framework.aidl -o/home/pi/Proyectos/Claude/kora-organizer/kora-android/build/generated/aidl_source_output_dir/debug/out -I/home/pi/Proyectos/Claude/kora-organizer/kora-android/src/main/aidl -I/home/pi/Proyectos/Claude/kora-organizer/kora-android/src/debug/aidl -d/tmp/aidl9965210466568446191.d /home/pi/Proyectos/Claude/kora-organizer/kora-android/src/main/aidl/eus/bihurri/kora/android/ipc/IKoraStreamCallback.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package eus.bihurri.kora.android.ipc;
/** Receives the answer to one IKoraNode.callReceiving (since protocol version 2). */
public interface IKoraStreamCallback extends android.os.IInterface
{
  /** Default implementation for IKoraStreamCallback. */
  public static class Default implements eus.bihurri.kora.android.ipc.IKoraStreamCallback
  {
    /**
     * CBOR KoraResponse, success or failure. A success comes with [bytes], the read end of a pipe that carries
     * exactly [sizeBytes] bytes, which the receiver owns and closes; a failure comes with a null [bytes] and a
     * [sizeBytes] of 0.
     */
    @Override public void onResponse(byte[] response, android.os.ParcelFileDescriptor bytes, long sizeBytes) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements eus.bihurri.kora.android.ipc.IKoraStreamCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an eus.bihurri.kora.android.ipc.IKoraStreamCallback interface,
     * generating a proxy if needed.
     */
    public static eus.bihurri.kora.android.ipc.IKoraStreamCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof eus.bihurri.kora.android.ipc.IKoraStreamCallback))) {
        return ((eus.bihurri.kora.android.ipc.IKoraStreamCallback)iin);
      }
      return new eus.bihurri.kora.android.ipc.IKoraStreamCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onResponse:
        {
          byte[] _arg0;
          _arg0 = data.createByteArray();
          android.os.ParcelFileDescriptor _arg1;
          _arg1 = _Parcel.readTypedObject(data, android.os.ParcelFileDescriptor.CREATOR);
          long _arg2;
          _arg2 = data.readLong();
          this.onResponse(_arg0, _arg1, _arg2);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements eus.bihurri.kora.android.ipc.IKoraStreamCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * CBOR KoraResponse, success or failure. A success comes with [bytes], the read end of a pipe that carries
       * exactly [sizeBytes] bytes, which the receiver owns and closes; a failure comes with a null [bytes] and a
       * [sizeBytes] of 0.
       */
      @Override public void onResponse(byte[] response, android.os.ParcelFileDescriptor bytes, long sizeBytes) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeByteArray(response);
          _Parcel.writeTypedObject(_data, bytes, 0);
          _data.writeLong(sizeBytes);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onResponse, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onResponse = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "eus.bihurri.kora.android.ipc.IKoraStreamCallback";
  /**
   * CBOR KoraResponse, success or failure. A success comes with [bytes], the read end of a pipe that carries
   * exactly [sizeBytes] bytes, which the receiver owns and closes; a failure comes with a null [bytes] and a
   * [sizeBytes] of 0.
   */
  public void onResponse(byte[] response, android.os.ParcelFileDescriptor bytes, long sizeBytes) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
