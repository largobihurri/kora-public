/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /home/pi/Android/Sdk/build-tools/36.0.0/aidl -p/home/pi/Android/Sdk/platforms/android-37.0/framework.aidl -o/home/pi/Proyectos/Claude/kora-organizer/kora-android/build/generated/aidl_source_output_dir/debug/out -I/home/pi/Proyectos/Claude/kora-organizer/kora-android/src/main/aidl -I/home/pi/Proyectos/Claude/kora-organizer/kora-android/src/debug/aidl -d/tmp/aidl8792014058963755259.d /home/pi/Proyectos/Claude/kora-organizer/kora-android/src/main/aidl/eus/bihurri/kora/android/ipc/IKoraNode.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package eus.bihurri.kora.android.ipc;
/**
 * Binder interface of a Kora node, served by KoraNodeService. Internal to the library: apps use KoraNode.
 * 
 * Every payload is an opaque CBOR envelope, so the interface never changes when a capability evolves.
 * The server identifies the caller from the Binder transaction (uid and signature), never from the payload.
 * 
 * Compatibility: [protocolVersion] must stay the first method (it keeps transaction code 1 in every version)
 * so that a client can always read it before using anything else. New methods are only appended, never inserted
 * or reordered, so every method keeps its transaction code.
 * 
 * Methods per protocol version (KoraAndroid.PROTOCOL_VERSION):
 * - 1: protocolVersion, describe, call, subscribe (transaction codes 1 to 4).
 * - 2: adds callSending and callReceiving (codes 5 and 6), the byte streams beside a call. A client calls them only
 *   on a peer that reported 2 or more; a peer on version 1 does not know them.
 */
public interface IKoraNode extends android.os.IInterface
{
  /** Default implementation for IKoraNode. */
  public static class Default implements eus.bihurri.kora.android.ipc.IKoraNode
  {
    /** Version of this interface; see KoraAndroid.PROTOCOL_VERSION. */
    @Override public int protocolVersion() throws android.os.RemoteException
    {
      return 0;
    }
    /** CBOR NodeDescriptor of the node. Cheap; fails with SecurityException for callers that are not trusted. */
    @Override public byte[] describe() throws android.os.RemoteException
    {
      return null;
    }
    /** Serves one CBOR KoraRequest and answers a CBOR KoraResponse through [callback], exactly once. */
    @Override public void call(byte[] request, eus.bihurri.kora.android.ipc.IKoraCallback callback) throws android.os.RemoteException
    {
    }
    /**
     * Opens the stream described by a CBOR SubscribeRequest. Events, a failure (CBOR KoraError) or the end of the
     * stream arrive on [sink]; the returned handle cancels the subscription.
     */
    @Override public eus.bihurri.kora.android.ipc.IKoraSubscription subscribe(byte[] request, eus.bihurri.kora.android.ipc.IKoraEventSink sink) throws android.os.RemoteException
    {
      return null;
    }
    /**
     * Since version 2. Serves one CBOR KoraRequest of an upload operation, whose bytes arrive on [bytes]: the read
     * end of a pipe, or a file the caller opened read-only, carrying exactly [sizeBytes] bytes. Answers a CBOR
     * KoraResponse through [callback], exactly once. The server owns its copy of [bytes] and closes it on every path;
     * the caller closes its own copy once this transaction is sent.
     */
    @Override public void callSending(byte[] request, android.os.ParcelFileDescriptor bytes, long sizeBytes, eus.bihurri.kora.android.ipc.IKoraCallback callback) throws android.os.RemoteException
    {
    }
    /**
     * Since version 2. Serves one CBOR KoraRequest of a download operation and answers through [callback], exactly
     * once: a success with the read end of a pipe that carries the bytes, or a failure with none.
     */
    @Override public void callReceiving(byte[] request, eus.bihurri.kora.android.ipc.IKoraStreamCallback callback) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements eus.bihurri.kora.android.ipc.IKoraNode
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an eus.bihurri.kora.android.ipc.IKoraNode interface,
     * generating a proxy if needed.
     */
    public static eus.bihurri.kora.android.ipc.IKoraNode asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof eus.bihurri.kora.android.ipc.IKoraNode))) {
        return ((eus.bihurri.kora.android.ipc.IKoraNode)iin);
      }
      return new eus.bihurri.kora.android.ipc.IKoraNode.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_protocolVersion:
        {
          int _result = this.protocolVersion();
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_describe:
        {
          byte[] _result = this.describe();
          reply.writeNoException();
          reply.writeByteArray(_result);
          break;
        }
        case TRANSACTION_call:
        {
          byte[] _arg0;
          _arg0 = data.createByteArray();
          eus.bihurri.kora.android.ipc.IKoraCallback _arg1;
          _arg1 = eus.bihurri.kora.android.ipc.IKoraCallback.Stub.asInterface(data.readStrongBinder());
          this.call(_arg0, _arg1);
          break;
        }
        case TRANSACTION_subscribe:
        {
          byte[] _arg0;
          _arg0 = data.createByteArray();
          eus.bihurri.kora.android.ipc.IKoraEventSink _arg1;
          _arg1 = eus.bihurri.kora.android.ipc.IKoraEventSink.Stub.asInterface(data.readStrongBinder());
          eus.bihurri.kora.android.ipc.IKoraSubscription _result = this.subscribe(_arg0, _arg1);
          reply.writeNoException();
          reply.writeStrongInterface(_result);
          break;
        }
        case TRANSACTION_callSending:
        {
          byte[] _arg0;
          _arg0 = data.createByteArray();
          android.os.ParcelFileDescriptor _arg1;
          _arg1 = _Parcel.readTypedObject(data, android.os.ParcelFileDescriptor.CREATOR);
          long _arg2;
          _arg2 = data.readLong();
          eus.bihurri.kora.android.ipc.IKoraCallback _arg3;
          _arg3 = eus.bihurri.kora.android.ipc.IKoraCallback.Stub.asInterface(data.readStrongBinder());
          this.callSending(_arg0, _arg1, _arg2, _arg3);
          break;
        }
        case TRANSACTION_callReceiving:
        {
          byte[] _arg0;
          _arg0 = data.createByteArray();
          eus.bihurri.kora.android.ipc.IKoraStreamCallback _arg1;
          _arg1 = eus.bihurri.kora.android.ipc.IKoraStreamCallback.Stub.asInterface(data.readStrongBinder());
          this.callReceiving(_arg0, _arg1);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements eus.bihurri.kora.android.ipc.IKoraNode
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /** Version of this interface; see KoraAndroid.PROTOCOL_VERSION. */
      @Override public int protocolVersion() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_protocolVersion, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** CBOR NodeDescriptor of the node. Cheap; fails with SecurityException for callers that are not trusted. */
      @Override public byte[] describe() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        byte[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_describe, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createByteArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Serves one CBOR KoraRequest and answers a CBOR KoraResponse through [callback], exactly once. */
      @Override public void call(byte[] request, eus.bihurri.kora.android.ipc.IKoraCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeByteArray(request);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_call, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      /**
       * Opens the stream described by a CBOR SubscribeRequest. Events, a failure (CBOR KoraError) or the end of the
       * stream arrive on [sink]; the returned handle cancels the subscription.
       */
      @Override public eus.bihurri.kora.android.ipc.IKoraSubscription subscribe(byte[] request, eus.bihurri.kora.android.ipc.IKoraEventSink sink) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        eus.bihurri.kora.android.ipc.IKoraSubscription _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeByteArray(request);
          _data.writeStrongInterface(sink);
          boolean _status = mRemote.transact(Stub.TRANSACTION_subscribe, _data, _reply, 0);
          _reply.readException();
          _result = eus.bihurri.kora.android.ipc.IKoraSubscription.Stub.asInterface(_reply.readStrongBinder());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Since version 2. Serves one CBOR KoraRequest of an upload operation, whose bytes arrive on [bytes]: the read
       * end of a pipe, or a file the caller opened read-only, carrying exactly [sizeBytes] bytes. Answers a CBOR
       * KoraResponse through [callback], exactly once. The server owns its copy of [bytes] and closes it on every path;
       * the caller closes its own copy once this transaction is sent.
       */
      @Override public void callSending(byte[] request, android.os.ParcelFileDescriptor bytes, long sizeBytes, eus.bihurri.kora.android.ipc.IKoraCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeByteArray(request);
          _Parcel.writeTypedObject(_data, bytes, 0);
          _data.writeLong(sizeBytes);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_callSending, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      /**
       * Since version 2. Serves one CBOR KoraRequest of a download operation and answers through [callback], exactly
       * once: a success with the read end of a pipe that carries the bytes, or a failure with none.
       */
      @Override public void callReceiving(byte[] request, eus.bihurri.kora.android.ipc.IKoraStreamCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeByteArray(request);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_callReceiving, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_protocolVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_describe = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_call = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_subscribe = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_callSending = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_callReceiving = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "eus.bihurri.kora.android.ipc.IKoraNode";
  /** Version of this interface; see KoraAndroid.PROTOCOL_VERSION. */
  public int protocolVersion() throws android.os.RemoteException;
  /** CBOR NodeDescriptor of the node. Cheap; fails with SecurityException for callers that are not trusted. */
  public byte[] describe() throws android.os.RemoteException;
  /** Serves one CBOR KoraRequest and answers a CBOR KoraResponse through [callback], exactly once. */
  public void call(byte[] request, eus.bihurri.kora.android.ipc.IKoraCallback callback) throws android.os.RemoteException;
  /**
   * Opens the stream described by a CBOR SubscribeRequest. Events, a failure (CBOR KoraError) or the end of the
   * stream arrive on [sink]; the returned handle cancels the subscription.
   */
  public eus.bihurri.kora.android.ipc.IKoraSubscription subscribe(byte[] request, eus.bihurri.kora.android.ipc.IKoraEventSink sink) throws android.os.RemoteException;
  /**
   * Since version 2. Serves one CBOR KoraRequest of an upload operation, whose bytes arrive on [bytes]: the read
   * end of a pipe, or a file the caller opened read-only, carrying exactly [sizeBytes] bytes. Answers a CBOR
   * KoraResponse through [callback], exactly once. The server owns its copy of [bytes] and closes it on every path;
   * the caller closes its own copy once this transaction is sent.
   */
  public void callSending(byte[] request, android.os.ParcelFileDescriptor bytes, long sizeBytes, eus.bihurri.kora.android.ipc.IKoraCallback callback) throws android.os.RemoteException;
  /**
   * Since version 2. Serves one CBOR KoraRequest of a download operation and answers through [callback], exactly
   * once: a success with the read end of a pipe that carries the bytes, or a failure with none.
   */
  public void callReceiving(byte[] request, eus.bihurri.kora.android.ipc.IKoraStreamCallback callback) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
