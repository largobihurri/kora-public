/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /home/pi/Android/Sdk/build-tools/36.0.0/aidl -p/home/pi/Android/Sdk/platforms/android-37.0/framework.aidl -o/home/pi/Proyectos/Claude/kora-organizer/kora-android/build/generated/aidl_source_output_dir/debug/out -I/home/pi/Proyectos/Claude/kora-organizer/kora-android/src/main/aidl -I/home/pi/Proyectos/Claude/kora-organizer/kora-android/src/debug/aidl -d/tmp/aidl9423567641316144899.d /home/pi/Proyectos/Claude/kora-organizer/kora-android/src/main/aidl/eus/bihurri/kora/android/ipc/IKoraCallback.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package eus.bihurri.kora.android.ipc;
/** Receives the answer to one call. */
public interface IKoraCallback extends android.os.IInterface
{
  /** Default implementation for IKoraCallback. */
  public static class Default implements eus.bihurri.kora.android.ipc.IKoraCallback
  {
    /** CBOR KoraResponse, success or failure. */
    @Override public void onResponse(byte[] response) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements eus.bihurri.kora.android.ipc.IKoraCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an eus.bihurri.kora.android.ipc.IKoraCallback interface,
     * generating a proxy if needed.
     */
    public static eus.bihurri.kora.android.ipc.IKoraCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof eus.bihurri.kora.android.ipc.IKoraCallback))) {
        return ((eus.bihurri.kora.android.ipc.IKoraCallback)iin);
      }
      return new eus.bihurri.kora.android.ipc.IKoraCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onResponse:
        {
          byte[] _arg0;
          _arg0 = data.createByteArray();
          this.onResponse(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements eus.bihurri.kora.android.ipc.IKoraCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /** CBOR KoraResponse, success or failure. */
      @Override public void onResponse(byte[] response) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeByteArray(response);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onResponse, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onResponse = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "eus.bihurri.kora.android.ipc.IKoraCallback";
  /** CBOR KoraResponse, success or failure. */
  public void onResponse(byte[] response) throws android.os.RemoteException;
}
